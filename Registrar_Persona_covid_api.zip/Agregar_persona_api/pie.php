</div>
    </div>
    <p>
    <div class = "wrapper">
    <center><strong>Derechos reservado <?= date('Y'); ?></strong></center> 
</p>
    </div>    
</body>
</html>